#ifndef SCSI_SCSI_H_BACKPORT
#define SCSI_SCSI_H_BACKPORT

#include_next <scsi/scsi.h>

#define SCSI_MAX_VARLEN_CDB_SIZE 260
#endif
