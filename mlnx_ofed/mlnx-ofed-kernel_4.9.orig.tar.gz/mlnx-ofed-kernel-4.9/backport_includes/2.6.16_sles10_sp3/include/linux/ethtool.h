#ifndef BACKPORT_LINUX_ETHTOOL
#define BACKPORT_LINUX_ETHTOOL

#include_next <linux/ethtool.h>

#define ETHTOOL_FWVERS_LEN      32

#endif
