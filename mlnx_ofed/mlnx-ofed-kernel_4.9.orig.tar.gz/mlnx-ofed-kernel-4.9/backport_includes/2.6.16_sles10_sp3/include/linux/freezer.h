#ifndef BACKPORT_LINUX_FREEZER_H
#define BACKPORT_LINUX_FREEZER_H

static inline void set_freezable(void) {}

#endif
