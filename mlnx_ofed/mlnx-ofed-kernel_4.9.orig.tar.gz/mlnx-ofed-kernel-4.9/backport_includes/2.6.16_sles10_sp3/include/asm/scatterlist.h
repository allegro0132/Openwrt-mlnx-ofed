#if defined(__ia64__)
#include <linux/pci.h>
#endif
#include <asm/types.h>
#include_next <asm/scatterlist.h>
