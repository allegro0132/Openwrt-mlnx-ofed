#ifndef _COMPAT_NET_TC_ACT_TC_MPLS_H
#define _COMPAT_NET_TC_ACT_TC_MPLS_H 1

#include "../../../compat/config.h"

#ifdef HAVE_NET_TC_ACT_TC_MPLS_H
#include_next <net/tc_act/tc_mpls.h>
#endif

#endif /* _COMPAT_NET_TC_ACT_TC_MPLS_H */
