#ifndef _COMPAT_LINUX_SIZES_H
#define _COMPAT_LINUX_SIZES_H 1

#include "../../compat/config.h"

#include_next <linux/sizes.h>

#endif /* _COMPAT_LINUX_SIZES_H */
