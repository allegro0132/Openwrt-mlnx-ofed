#ifndef _COMPAT_LINUX_POLL_H
#define _COMPAT_LINUX_POLL_H

#include "../../compat/config.h"

#include_next <linux/poll.h>
#include <linux/eventpoll.h>

#endif /* _COMPAT_LINUX_POLL_H */
