#ifndef LINUX_IF_BONDING_H
#define LINUX_IF_BONDING_H

#include "../../../compat/config.h"

/* just include the header from the correct location */
#include_next <uapi/linux/if_bonding.h>


#endif /* LINUX_IF_BONDING_H */
