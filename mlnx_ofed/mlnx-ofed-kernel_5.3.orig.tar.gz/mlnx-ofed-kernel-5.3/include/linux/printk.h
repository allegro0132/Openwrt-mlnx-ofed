#ifndef _COMPAT_LINUX_PRINTK_H
#define _COMPAT_LINUX_PRINTK_H 1

#include <linux/version.h>
#include "../../compat/config.h"

#include_next <linux/printk.h>

#endif	/* _COMPAT_LINUX_PRINTK_H */
