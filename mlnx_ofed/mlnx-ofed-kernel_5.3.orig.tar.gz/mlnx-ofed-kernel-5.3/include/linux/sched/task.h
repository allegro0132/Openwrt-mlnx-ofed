#ifndef COMPAT_LINUX_SCHED_TASK_H
#define COMPAT_LINUX_SCHED_TASK_H

#include "../../../compat/config.h"

#ifdef HAVE_SCHED_TASK_H
#include_next <linux/sched/task.h>
#endif

#endif /* COMPAT_LINUX_SCHED_TASK_H */
