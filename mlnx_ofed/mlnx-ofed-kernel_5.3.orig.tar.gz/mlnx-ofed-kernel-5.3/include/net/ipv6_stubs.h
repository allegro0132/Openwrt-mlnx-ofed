#ifndef COMPAT_IPV6_STUBS_H
#define COMPAT_IPV6_STUBS_H 1

#include "../../compat/config.h"

#ifdef HAVE_IPV6_STUBS_H
#include_next <net/ipv6_stubs.h>
#endif

#endif /* COMPAT_IPV6_STUBS_H */
